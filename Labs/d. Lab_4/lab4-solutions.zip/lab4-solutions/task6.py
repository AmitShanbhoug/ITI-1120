#0, 1, 2, 3, 4, 5, 6, 7, 8 , 9, 10
for i in range(11):
     print(i, end=" ")
print()

#1, 2, 3, 4, 5, 6, 7, 8, 9
for i in range(1, 10):
     print(i, end=" ")
print()

#0, 2, 4, 6, 8
for i in range(0, 9, 2):
     print(i, end=" ")
print()
#1, 3, 5, 7, 9
for i in range(1, 10,2):
     print(i, end=" ")
print()
#20, 30, 40, 50, 60
for i in range(20, 61, 10):
     print(i, end=" ")
print()
#10, 9, 8, 7, 6, 5, 4, 3, 2, 1
for i in range(10, 0, -1):
     print(i, end=" ")
print()

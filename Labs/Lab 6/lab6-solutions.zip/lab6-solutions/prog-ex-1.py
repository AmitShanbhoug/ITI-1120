sum_odd_while_v2(n):
     '''(int)->int
        Returns the sum of all odd integers between 5 and n
        '''

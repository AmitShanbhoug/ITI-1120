import turtle
s=turtle.Screen()
t=turtle.Turtle(shape='turtle')

#semicircle
t.penup()
t.goto(-300,0)
t.pendown()
t.setheading(-45)
t.circle(50,90)

# your code should go right after this line

t.penup()
t.goto(-230,0)
t.pendown()
t.setheading(-45)
t.circle(50,90)

t.penup()
t.goto(-160,0)
t.pendown()
t.setheading(-45)
t.circle(50,90)

t.penup()
t.goto(-90,0)
t.pendown()
t.setheading(-45)
t.circle(50,90)

t.penup()
t.goto(-20,0)
t.pendown()
t.setheading(-45)
t.circle(50,90)

t.penup()
t.goto(50,0)
t.pendown()
t.setheading(-45)
t.circle(50,90)

t.penup()
t.goto(120,0)
t.pendown()
t.setheading(-45)
t.circle(50,90)

t.penup()
t.goto(190,0)
t.pendown()
t.setheading(-45)
t.circle(50,90)


t.penup()
t.goto(-100,200)
t.pendown()
t.circle(50)
t.penup()
t.goto(0,-50)



print ("hello")
print (1+2)
